#define MAX 1024
#define ReadEnd  0
#define WriteEnd 1